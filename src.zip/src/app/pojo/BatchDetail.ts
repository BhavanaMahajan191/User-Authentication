export class BatchDetail{
    batch_admission_id:number=0;
    batch_id:number=0;
    enq_no:number=0;
    batch_join_date:string="";
    batch_srno:number=0;
    organizationid:number=0;
}
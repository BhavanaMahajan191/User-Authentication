import { BatchDetail } from "./BatchDetail";

export class BatchMaster{
        batch_id:number=0;
        course_no:number=0;
        starting_date:string="";
        batch_time:string=" ";
        faculty_id:number=0;
        master_sr_no:number=0;
        organizationid:number=0;

        batchDetailsList: Array<BatchDetail> = new Array<BatchDetail>();   

}
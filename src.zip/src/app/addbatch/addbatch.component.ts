import { Component, OnInit } from '@angular/core';
import { BatchList } from '../pojo/BatchList';
import { DataService } from '../service/data.service';
@Component({
  selector: 'app-addbatch',
  templateUrl: './addbatch.component.html',
  styleUrls: ['./addbatch.component.css']
})
export class AddbatchComponent implements OnInit{

  addbatch:BatchList=new BatchList();
  constructor(private dataService:DataService){}
  ngOnInit(): void {
    
  }
  
}

import { Component, OnInit } from '@angular/core';
import { Admission } from '../pojo/admission';
import { AdmissiondataService } from '../service/admissiondata.service';
@Component({
  selector: 'app-admission',
  templateUrl: './admission.component.html',
  styleUrls: ['./admission.component.css']
})
export class AdmissionComponent implements OnInit{

  admission:any=[ ];
  admissionObj:Admission=new Admission ();
     flag:string="";

  constructor(private admissiondataService:AdmissiondataService){}
  ngOnInit(): void {
    this.fillList();
  }
   fillList()
  {
     this.admissiondataService.getData("admission").subscribe(data=>{this.admission=data;alert(JSON.stringify(this.admission));});
     this.clearData();
    }
  clearData(){
    this.admissionObj. admission_srno=0;
    this.admissionObj.admission_id=0;
    this.admissionObj.batch_add_id=0 ;
    this.admissionObj.total_course_fees=0;
    this.admissionObj.discount_amount=0;
    this.admissionObj.balance =0;
    this.admissionObj.organizationid=0;
  }
  edit()
  {
    this.admissiondataService.updateData("admission",this.admissionObj).subscribe(data=>{this.fillList();});
  }
  save()
  {
     this.admissiondataService.updateData("admission",this.admissionObj).subscribe(data=>{this.fillList();});
  }
  update(admission_srno:number)
  {
    this.admissiondataService.getData("admission" +admission_srno ).subscribe(data=>{this.admissionObj=data; });
  }
  delete(admission_srno:number)
  {
     let ans=confirm("Are You Sure You Want To Delete The Record..?")

    if(ans)
    this.admissiondataService.deleteData("admission/" + admission_srno).subscribe(data=>{this.fillList();});
  }
  }


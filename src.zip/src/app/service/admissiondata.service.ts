import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdmissiondataService {

  path:string="http://localhost:8084/";
  constructor(private httpClient:HttpClient) { }

  getData(url:string):Observable<any>
  {
    return this.httpClient.get(this.path + url);
  }

  insertData(url:string ,Obj:any):Observable<any>
  {
     return this.httpClient.post(this.path + url , Obj );
  }

  updateData(url:string,obj:any):Observable<any>
  {
    return this.httpClient.put(this.path + url,obj);
  }

  deleteData(url:string):Observable<any>
  {
    return this.httpClient.delete(this.path + url);
  }
}
